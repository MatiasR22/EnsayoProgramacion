import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-planilla',
  templateUrl: './planilla.component.html',
  styleUrls: ['./planilla.component.scss']
})
export class PlanillaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
